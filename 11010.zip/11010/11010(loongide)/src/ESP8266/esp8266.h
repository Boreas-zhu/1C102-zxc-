#ifndef __ESP8266_H
#define __ESP8266_H

#ifdef __cplusplus
extern "C" {
#endif

#include "ls1c102.h"

extern unsigned char Property_Data[];

#define post "/k1jnsefKkjy/ESP8266DUAN/user/ESP8266DUAN"
#define post_name "LightSwitch"

#define MQTT_set	"AT+MQTTUSERCFG=0,1,\"NULL\",\"ESP8266DUAN&k1jnsefKkjy\",\"eb3ca7873383e6193fa1b07c48d60b10de1ca6d0782ea9c45f9d3fe054c905ca\",0,0,\"\""
#define MQTT_Client "AT+MQTTCLIENTID=0,\"k1jnsefKkjy.ESP8266DUAN|securemode=2\\,signmethod=hmacsha256\\,timestamp=1720459134466|\""
#define MQTT_Pass "AT+MQTTCONN=0,\"iot-06z00drvj1rd3g9.mqtt.iothub.aliyuncs.com\",1883,1"

//extern char restart[];
//extern char cwmode[];
//extern char cwlap[];
//extern char cwjap[];
//extern char cifsr[];
//extern char cipmux[];
//extern char cipstart[];
//extern char cipsend[];
//extern char cipserver[];
//extern char cwlif[];
//extern char cipstatus[];
//extern char cipsto[];
//extern char cipmode[];
//extern char test[];

char* esp8266_check_cmd(char *str);
char esp8266_send_cmd(char *cmd,char *ack,uint16_t waittime);
void esp8266_start_trans(void);
void esp8266_send_data(char *cmd);
void ESP8266_Send(int Data1,int Data2);
void ESP8266_Received(char *PRO);

#ifdef __cplusplus
}
#endif

#endif

