#ifndef _USER_ADC_H
#define _USER_ADC_H

#ifdef __cplusplus
extern "C" {
#endif

void adc_init(void);

int adc_read(int ch);
int str2Hex( char *pstr);

#ifdef __cplusplus
}
#endif

#endif // _USER_ADC_H

