#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#include "bsp.h"
#include "console.h"
#include "ls1c102.h"
#include "ns16550.h"

#include "src/GPIO/user_gpio.h"
#include "src/WDG/ls1x_wdg.h"
#include "src/ESP8266/esp8266.h"
#include "src/ADC/user_adc.h"
#include "src/I2C/ls1c102_i2c.h"
#include "src/OLED/oled96.h"
#include "src/TIME/timer.h"

extern HW_PMU_t *g_pmu;
extern int printk(const char* format, ...);
extern int uart0_print(const char* format, ...);

int light;
int smoke;
char a[] = "LightSwitch";
char b[] = "light";


int main(void)
{
    WdgInit();
    printk("main() function\r\n");
    
    gpio_init(34, 0);
    gpio_init(20, 1);// GPIO20 ʹ�����
    gpio_init(13, 1);
    gpio_init(18, 1);
    delay_ms(300);
    gpio_write(13, 1);
    delay_ms(300);
    gpio_write(13, 0);
    delay_ms(800);
    gpio_write(18, 0);
    delay_ms(300);
    gpio_write(18, 1);
    delay_ms(800);

    gpio_iosel(4, 1);
    gpio_iosel(5, 1);
    I2C_InitTypeDef I2C_InitStruct0;
    I2C_StructInit(&I2C_InitStruct0);
    I2C_Init(&I2C_InitStruct0);
    delay_ms(100);
    OLED_Init();// ��ʼ�� OLED ģ��
    OLED_Clear();// OLED ���������ǽ�������Ļ����ɫ��

    adc_init();

    gpio_init(23,1);


    gpio_iosel(6, 1);
    gpio_iosel(7, 1);
    console0_init(115200);// ����0��ʼ
    
    esp8266_start_trans();		 // esp8266���г�ʼ��
    for (;;)
    {
        gpio_write(13, 1);// GPIO20 ����ߵ�ƽ
        delay_ms(100);
        gpio_write(13, 0);// GPIO20 ����͵�ƽ
        delay_ms(300);
        
        printk("ADC1 = %u\r\n", adc_read(1));   //��������ʼ����
        delay_ms(300);
        light=adc_read(1);
        smoke=adc_read(0)*100/4095;
        
        
        if(smoke<=30)
        {
            gpio_write(13, 0);
            gpio_write(18,1);
            gpio_init(23,0);
        }
        else if(smoke>30&&smoke<=32)
        {
            gpio_write(13, 1);
            gpio_write(18,1);
            gpio_init(23,0);
           

        }
        else if(smoke>32)
        {
            gpio_write(13, 1);
            gpio_write(18,0);
            gpio_init(23,1);
        }


        OLED_ShowCHinese(0, 0, 0);    //OLED��ʾ
        OLED_ShowCHinese(16, 0, 1);
        OLED_ShowCHinese(32, 0, 2);
        OLED_ShowCHinese(48, 0, 3);
        OLED_ShowNum(0,2,smoke/10,1,1);
        OLED_ShowNum(8,2,smoke%10,1,1);


        OLED_ShowCHinese(0, 4, 4);
        OLED_ShowCHinese(16, 4, 5);
        OLED_ShowCHinese(32, 4, 6);
        OLED_ShowCHinese(48, 4, 7);

        OLED_ShowNum(0,6,light/1000,1,1);
        OLED_ShowNum(8,6,light/100%10,1,1);
        OLED_ShowNum(16,6,light/10%10,1,1);
        OLED_ShowNum(24,6,light%10,1,1);

        
        ESP8266_Send(smoke,light);    //���ƶ˷�������

        delay_ms(2);
    }

    return 0;
}

